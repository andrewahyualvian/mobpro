package com.example.uts_mobpro

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
